-- --------------------------------------------------------

--
-- 表的结构 `ecs_payment`
--

ALTER TABLE `ecs_payment` ADD `type` tinyint(1) unsigned NOT NULL DEFAULT '0';





