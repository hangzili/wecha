<?php

/**
 * ECSHOP Éý¼¶³ÌÐòÓïÑÔÎÄ¼þ
 * ============================================================================
 * °æÈ¨ËùÓÐ (C) 2005-2007 ¿µÊ¢´´Ïë£¨±±¾©£©¿Æ¼¼ÓÐÏÞ¹«Ë¾£¬²¢±£ÁôËùÓÐÈ¨Àû¡£
 * ÍøÕ¾µØÖ·: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * ÕâÊÇÒ»¸öÃâ·Ñ¿ªÔ´µÄÈí¼þ£»ÕâÒâÎ¶×ÅÄú¿ÉÒÔÔÚ²»ÓÃÓÚÉÌÒµÄ¿µÄµÄÇ°ÌáÏÂ¶Ô³ÌÐò´úÂë
 * ½øÐÐÐÞ¸Ä¡¢Ê¹ÓÃºÍÔÙ·¢²¼¡£
 * ============================================================================
 * $Author: dolphin $
 * $Date: 2008-07-03 13:41:01 +0800 (å››, 03  7 2008) $
 * $Id: zh_cn_gbk.php 14696 2008-07-03 05:41:01Z dolphin $
*/

$_LANG['prev_step']         = 'ÉÏÒ»²½£º';
$_LANG['next_step']         = 'ÏÂÒ»²½£º';
$_LANG['readme_title']                =  'ECSHOPÉý¼¶³ÌÐò µÚ1²½/¹²2²½ ËµÃ÷Ò³';
$_LANG['checking_title']                =  'ECShopÉý¼¶³ÌÐò µÚ2²½/¹²2²½ »·¾³¼ì²â';
$_LANG['check_system_environment']          = '¼ì²âÏµÍ³»·¾³';

$_LANG['copyright']                     = '&copy; 2005-2007 <a href="http://www.ecshop.com" target="_blank">¿µÊ¢´´Ïë£¨±±¾©£©¿Æ¼¼ÓÐÏÞ¹«Ë¾</a>¡£±£ÁôËùÓÐÈ¨Àû¡£';
$_LANG['is_last_version']             = 'ÄúµÄECSHOPÒÑÊÇ×îÐÂ°æ±¾£¬ÎÞÐèÉý¼¶¡£';

$_LANG['readme_page']                =  'ËµÃ÷Ò³';
$_LANG['notice'] = '±¾³ÌÐòÓÃÓÚ½« ECSHOP Éý¼¶µ½ <strong>%s</strong>¡£ÇëÎð±Ø°´ÕÕÒÔÏÂµÄÉý¼¶·½·¨½øÐÐÉý¼¶£¬·ñÔò¿ÉÄÜ²úÉúÎÞ·¨»Ö¸´µÄºó¹û¡£Èç¹ûÄãÒÑ¾­ÕûºÏÁËÂÛÌ³Èí¼þ£¬±¾´ÎÉý¼¶½«È¡ÏûÕûºÏ£¬ÒÔºó»áÔ±ÕûºÏÇëµ½ucenrerÖÐ½øÐÐÕûºÏ¡£';
$_LANG['usage1'] = 'ÇëÈ·ÈÏÒÑ¾­°²×°ÁË UCenter£¬·ñÔò£¬Çëµ½ <a href="http://www.discuz.com" target="_blank">Comsenz ²úÆ·ÖÐÐÄ</a> ÏÂÔØ²¢ÇÒ°²×°£¬È»ºóÔÙ¼ÌÐø¡£<br />';
$_LANG['usage2']  = '<a href="../admin">µÇÂ¼ºóÌ¨</a>£¬<span style="color:red;font-weight:bold;font-size:18px;">±¸·Ý</span>Êý¾Ý¿â×ÊÁÏ£»';
$_LANG['usage3']  = '¹Ø±ÕÏÖÓÐµÄ ECSHOP %s ÏµÍ³£»';
$_LANG['usage4']  = '¸²¸ÇÐÔÉÏ´« ECSHOP %s µÄÈ«²¿ÎÄ¼þµ½·þÎñÆ÷£»';
$_LANG['usage5']  = 'ÉÏ´«±¾³ÌÐòµ½ ECSHOP ËùÔÚµÄÄ¿Â¼ÖÐ£»';
$_LANG['usage6']  = 'ÔËÐÐ±¾³ÌÐò£¬Ö±µ½³öÏÖÉý¼¶Íê³ÉµÄÌáÊ¾¡£';
$_LANG['method']  = 'Éý¼¶·½·¨';
$_LANG['charset']  = '±àÂëÈ·ÈÏ';
$_LANG['readme_charset']  = '<span style="color:red"><strong>ÖØÒª£º</strong>MySQLµÄ±àÂë±ØÐëÓëECShopµÄ±àÂëÒ»ÖÂ¡£Èç¹ûÁ½ÕßÓÐ²»Ò»ÖÂÐÔ£¬ÒÔÄúÑ¡ÔñµÄÎª×¼£¡</span>';
$_LANG['mysql_charset']  = 'MySQLÊý¾Ý¿âµÄ±àÂë£º';
$_LANG['ecshop_charset']  = 'ECShopµÄ±àÂë£º';
$_LANG['unknow_charset']  = 'Î´Öª±àÂë';
$_LANG['sel_charset_0']  = 'MySQLÓëECShopµÄ±àÂëÒ»ÖÂ';
$_LANG['sel_charset_1']  = 'ÇëÈ·ÈÏMySQLÓëECShopµÄ±àÂë£º%s ';
$_LANG['sel_charset_2']  = 'ÇëÈ·ÈÏMySQLµÄ±àÂë£º%s ';
$_LANG['sel_charset_3']  = 'ÇëÈ·ÈÏECShopµÄ±àÂë£º%s ';
$_LANG['opt_charset']  = '<select name="select_charset" id="select_charset">
    <option value="">ÇëÑ¡Ôñ±àÂëÀàÐÍ</option>
    <option value="utf-8">utf-8</option>
    <option value="gbk">gbk</option>
</select>';
$_LANG['faq']  = '³£¼ûÎÊÌâ';

$_LANG['basic_config']                           = '»ù±¾ÅäÖÃÐÅÏ¢';
$_LANG['config_path']                           = 'ÅäÖÃÎÄ¼þÂ·¾¶';
$_LANG['db_host']                           = 'Êý¾Ý¿âÖ÷»ú';
$_LANG['db_name']                           = 'Êý¾Ý¿âÃû';
$_LANG['db_user']                           = 'ÓÃ»§Ãû';
$_LANG['db_pass']                           = 'ÃÜÂë';
$_LANG['db_prefix']                         = '±íÇ°×º';
$_LANG['timezone']                         = 'Ê±ÇøÉèÖÃ';
$_LANG['cookie_path']                      = 'COOKIEÂ·¾¶';
$_LANG['admin_dir']                        = '¹ÜÀíÖÐÐÄ¸ùÂ·¾¶';

$_LANG['dir_priv_checking']                 = 'Ä¿Â¼È¨ÏÞ¼ì²â';
$_LANG['template_writable_checking']        = 'Ä£°å¿ÉÐ´ÐÔ¼ì²é';
$_LANG['rename_priv_checking']              = 'ÌØ¶¨Ä¿Â¼ÐÞ¸ÄÈ¨ÏÞ¼ì²é';
$_LANG['cannt_write']                     =  '²»¿ÉÐ´';
$_LANG['can_write']                       = '¿ÉÐ´';
$_LANG['cannt_modify']                    = '²»¿ÉÐÞ¸Ä';
$_LANG['not_exists']                      = '²»´æÔÚ';
$_LANG['recheck']                         = 'ÖØÐÂ¼ì²é';
$_LANG['all_are_writable']                = 'ËùÓÐÄ£°å£¬È«²¿¿ÉÐ´';

$_LANG['update_now']                    = 'Á¢¼´Éý¼¶';
$_LANG['done'] = '¹§Ï²£¬ÄúÒÑ¾­³É¹¦Éý¼¶µ½ECSHOP <strong>%s</strong>';
$_LANG['upgrade_error_title']                    = 'ECShopÉý¼¶³ÌÐò Éý¼¶Ê§°Ü';
$_LANG['upgrade_done_title'] = 'ECShopÉý¼¶³ÌÐò Éý¼¶³É¹¦';
$_LANG['go_to_view_my_ecshop'] = 'Ç°Íù ECSHOP Ê×Ò³';
$_LANG['go_to_view_control_panel'] = 'Ç°Íù ECSHOP ºóÌ¨¹ÜÀíÖÐÐÄ ';
$_LANG['dir_readonly']          = '%s ÎÄ¼þ²»¿ÉÐ´£¬Çë¼ì²éÄúµÄ·þÎñÆ÷ÉèÖÃ¡£';
$_LANG['monitor_title']          = 'Éý¼¶³ÌÐò¼àÊÓÆ÷';
$_LANG['wait_please']          = 'ÕýÔÚÉý¼¶ÖÐ£¬ÇëÉÔºò¡­¡­¡­¡­';
$_LANG['js_error']          = '¿Í»§¶ËJavaScript½Å±¾·¢Éú´íÎó¡£';
$_LANG['create_ver_failed']          = '´´½¨°æ±¾¶ÔÏóÊ§°Ü';

/* ¿Í»§¶ËJSÓïÑÔÏî */
$_LANG['js_languages']['display_detail']                   = 'ÏÔÊ¾Ï¸½Ú';
$_LANG['js_languages']['exception']                   = '·¢ÉúÒì³£';
$_LANG['js_languages']['hide_detail']                   = 'Òþ²ØÏ¸½Ú';
$_LANG['js_languages']['suspension_points']                   = '¡­¡­¡­¡­';
$_LANG['js_languages']['initialize']                   = '³õÊ¼»¯';
$_LANG['js_languages']['wait_please']               = 'ÕýÔÚÉý¼¶ÖÐ£¬ÇëÉÔºò¡­¡­¡­¡­';
$_LANG['js_languages']['has_been_stopped']                    = 'Éý¼¶½ø³ÌÒÑÖÐÖ¹';
$_LANG['js_languages']['is_last_version']                   = 'ÄúµÄECSHOPÒÑÊÇ×îÐÂ°æ±¾£¬ÎÞÐèÉý¼¶¡£';
$_LANG['js_languages']['from']                   = 'ÕýÔÚ´Ó';
$_LANG['js_languages']['to']                   = 'Éý¼¶µ½';
$_LANG['js_languages']['update_files']                   = 'Éý¼¶ÎÄ¼þ';
$_LANG['js_languages']['update_structure']                   = 'Éý¼¶Êý¾Ý½á¹¹';
$_LANG['js_languages']['update_others']                   = 'Éý¼¶ÆäËü';
$_LANG['js_languages']['success']                   = 'Íê³É';
$_LANG['js_languages']['fail']                      = 'Ê§°Ü';
$_LANG['js_languages']['notice']                      = '³ö´í';
$_LANG['js_languages']['dump_database'] = '±¸·ÝÊý¾Ý';
$_LANG['js_languages']['rollback'] = '»Ö¸´Êý¾Ý';

/* UCenter °²×°ÅäÖÃ */
$_LANG['configure_uc'] = 'ÅäÖÃUCenter';
$_LANG['check_ucenter'] = 'ÌîÐ´Íê±Ï£¬½øÐÐÏÂÒ»²½';
$_LANG['ucapi'] = 'UCenter µÄ URL';
$_LANG['ucenter'] = 'ÇëÌîÐ´ UCenter Ïà¹ØÐÅÏ¢£º';
$_LANG['ucfounderpw'] = 'UCenter ´´Ê¼ÈËÃÜÂë£º';
$_LANG['uc_intro'] = 'UCenter ÊÇ Comsenz ¹«Ë¾²úÆ·µÄºËÐÄ·þÎñ³ÌÐò£¬Discuz! Board µÄ°²×°ºÍÔËÐÐÒÀÀµ´Ë³ÌÐò¡£Èç¹ûÄúÒÑ¾­°²×°ÁË UCenter£¬ÇëÌîÐ´ÒÔÏÂÐÅÏ¢¡£·ñÔò£¬Çëµ½ <a href="http://www.discuz.com" target="_blank">Comsenz ²úÆ·ÖÐÐÄ</a> ÏÂÔØ²¢ÇÒ°²×°£¬È»ºóÔÙ¼ÌÐø¡£<br /><br />';

$_LANG['users_importto_ucenter'] = '»áÔ±Êý¾Ýµ¼Èëµ½ UCenter';
$_LANG['user_startid'] = '»áÔ± ID ÆðÊ¼Öµ£º';
$_LANG['user_startid_intro'] = '<p>´ËÆðÊ¼»áÔ±IDÎª%s¡£ÈçÔ­ ID Îª 888 µÄ»áÔ±½«±äÎª %s+888 µÄÖµ¡£</p><br /><p><span style="color:#F00;font-size:1.2em;font-weight:bold;">ÌáÐÑ£ºµ¼Èë»áÔ±Êý¾ÝÇ°ÇëÔÝÍ£¸÷¸öÓ¦ÓÃ(ÈçDiscuz!, SupeSiteµÈ)</span></p><br />';
$_LANG['maxuid_err'] = 'ÆðÊ¼»áÔ± ID ±ØÐë´óÓÚµÈÓÚ';
$_LANG['ucenter_import_members'] = 'µ¼Èë»áÔ±Êý¾Ýµ½UCenter';
$_LANG['ucenter_no_database'] = '<span style="color:#F00;font-size:1.5em;"><b>²»ÄÜÁ¬½Óµ½UCenterµÄÊý¾Ý¿â£¬Éý¼¶²»ÄÜÍê³É£¬ÇëÁªÏµ¹ÜÀíÔ±£¡</b></span>';
$_LANG['user_merge_method'] = '»áÔ±ºÏ²¢·½Ê½£º';
$_LANG['user_merge_method_1'] = '½«ÓëUCÓÃ»§ÃûºÍÃÜÂëÏàÍ¬µÄÓÃ»§Ç¿ÖÆÎªÍ¬Ò»ÓÃ»§';
$_LANG['user_merge_method_2'] = '½«ÓëUCÓÃ»§ÃûºÍÃÜÂëÏàÍ¬µÄÓÃ»§²»µ¼ÈëUCÓÃ»§';
$_LANG['ucenter_not_match'] = '<span style="color:#F00;font-size:1.2em;"><b>UCenterÓëECShop×Ö·û±àÂë²»Æ¥Åä£¬Éý¼¶²»ÄÜÍê³É£¬ÇëÁªÏµ¹ÜÀíÔ±£¡</b></span>';

?>
