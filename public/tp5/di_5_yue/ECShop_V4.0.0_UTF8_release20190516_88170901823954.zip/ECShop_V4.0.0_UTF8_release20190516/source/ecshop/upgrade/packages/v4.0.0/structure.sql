-- --------------------------------------------------------

--
-- 表的结构 `ecs_goods_gallery`
--

ALTER TABLE `ecs_goods_gallery` ADD `sort_order` SMALLINT( 4 ) unsigned NOT NULL DEFAULT '30';





