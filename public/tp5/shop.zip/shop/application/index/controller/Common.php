<?php
namespace app\index\controller;
use think\Controller;

class Common extends Controller
{
    /**查询导航 左侧分类数据 */
    function __construct()
    {
        parent::__construct();
        

    }
    /**查询导航 左侧分类数据 */
    function getCateInfo()
    {
        // 导航数据
        $cmodel = model('Category');
        $where=[
            ['parent_id','=',0],
            ['cate_nav_show','=',1],
        ];
        $navInfo = $cmodel->where($where)->limit(7)->select();
        // dump($navInfo);exit;
        // 左侧分类数据
        $cwhere=[
            
            ['cate_show','=',1],
        ];
        $cInfo = $cmodel->field('cate_id,cate_name,parent_id')->where($cwhere)->select()->toArray();
         
       
        // 调用函数分类处理数据
            $cateInfo=CreateTree($cInfo);
            // print_r($cateInfo);exit;
            
        
        $this->assign('navInfo',$navInfo);
         $this->assign('cateInfo',$cateInfo);


    }
    function checkLogin(){
        return session("?userData");
    }
    //浏览记录同步
    function asyncHistory()
    {
        $data=cookie('data');
        if(!empty($data)){
            $user_id=session('userData.user_id');
            foreach($data as $k=>$v){
                $data[$k]['user_id']=$user_id;
            }
            $History_model=model('History');
            $res=$History_model->saveALL($data);
            if($res){
                cookie('data',null);
            }
        }
    }
    //检查库存是否够
   public function checkByNumber($by_number,$goods_id,$cartes=0)
   {
        $by_number += $cartes;
        $goods_model=model('Goods');
        $goodsInfo=$goods_model->where('goods_id',$goods_id)->value('goods_num');
        if($by_number>$goodsInfo){
            //库存不足
            return ['font'=>'库存不足，最多购买'.($goodsInfo-$cartes).'件','res'=>'2','by_number'=>$goodsInfo];
        }else{
            return true;
        }
   }
   //加入购物车同步  获取cookie里面的值，判断用户购物车里面有没有，如果没有就添加，如果有就更新  判断所有的加起来有没有比库存多
   public function asyncCart()
   {
        $data=cookie('cartInfo');
        if(!empty($data)){
            $cart_model=model('Cart');
            $user_id=session('userData.user_id');
            foreach ($data as $k=>$v) {
                $where=[
                    ['goods_id','=',$v['goods_id']],
                    ['user_id','=',$user_id]
                ];
                $info=$cart_model->where($where)->find();
                $by_number=$info['by_number'] + $v['by_number'];

                $result=$this->checkByNumber($v['by_number'],$v['goods_id'],$info['by_number']);
                if(is_array($result)){
                    $by_number=$result['by_number'];
                }
                //判断库里有没有，如果有就更新
                if(!empty($info)){
                    $cart_model->where($where)->update(['by_number'=>$by_number,'create_time'=>time()]);
                }else{
                    $v['user_id']=$user_id;
                    $cart_model->save($v);
                }
            }
            cookie('cartInfo',null);
        }else{
            return true;
            cookie('cartInfo',null);
        }
    }
    
}

 