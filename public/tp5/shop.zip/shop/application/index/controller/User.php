<?php
namespace app\index\controller;
use think\Controller;

class User extends Common
{
    //显示个人中心
    public function index()
    {
        return $this->fetch();
    }

    
}
