<?php

namespace app\index\model;

use think\Model;

class Address extends Model
{
    protected $pk = 'address_id';
    protected $table='shop_address';
}
