<?php

namespace app\index\model;

use think\Model;

class History extends Model
{
    protected $pk = 'h_id';
    protected $table='shop_history';
}
