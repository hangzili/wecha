<?php

namespace app\index\model;

use think\Model;

class Collect extends Model
{
    protected $table='shop_collect';
}
