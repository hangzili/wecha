<?php

namespace app\index\model;

use think\Model;

class OrderGoods extends Model
{
    protected $pk = 'o_id';
    protected $table='shop_order_goods';
}
