<?php

namespace app\index\model;

use think\Model;

class Carts extends Model
{
    protected $pk = 'c_id';
    protected $table='carts';
}
