<?php

namespace app\index\model;

use think\Model;

class OrderInfo extends Model
{
    protected $pk = 'order_id';
    protected $table='shop_order_info';
}
