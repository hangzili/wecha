<?php

namespace app\index\model;

use think\Model;

class Login extends Model
{
    public $pk='id';
    public $table="index_user";
}
