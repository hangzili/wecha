<?php

namespace app\index\model;

use think\Model;

class User_address extends Model
{
    protected $pk="address_id";
}
