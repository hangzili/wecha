<?php

namespace app\index\model;

use think\Model;

class Order_goods extends Model
{
    protected $pk='rec_id';
}
