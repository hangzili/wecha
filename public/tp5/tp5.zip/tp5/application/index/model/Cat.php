<?php

namespace app\index\model;

use think\Model;

class Cat extends Model
{
     protected $pk='goods_id';
}
