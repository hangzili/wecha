<?php

namespace app\index\model;

use think\Model;

class Order_info extends Model
{
    protected $pk='order_id';
}
