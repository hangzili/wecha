<?php

namespace app\index\model;

use think\Model;

class Staff extends Model
{
    protected $pk="id";
}
