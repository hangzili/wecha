<?php

namespace app\index\model;

use think\Model;

class Histroy extends Model
{
    protected $pk='t_id';
}
