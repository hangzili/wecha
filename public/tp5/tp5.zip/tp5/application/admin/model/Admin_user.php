<?php

namespace app\admin\model;

use think\Model;

class Admin_user extends Model
{
	
   public $pk='id';
   protected $autoWriteTimestamp = true;
}
