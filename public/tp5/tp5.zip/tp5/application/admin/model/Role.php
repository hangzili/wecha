<?php

namespace app\admin\model;

use think\Model;

class Role extends Model
{
    protected $pk='r_id';
}
