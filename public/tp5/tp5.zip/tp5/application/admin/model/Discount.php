<?php

namespace app\admin\model;

use think\Model;

class Discount extends Model
{
    protected $pk="d_id";
}
